<?php get_sidebar(); ?>

<div id="footer">
	<p>
		<?php printf(__('%1$s is powered by <a href="http://wordpress.org">WordPress</a>'), get_bloginfo('name')); ?>
		<br />
		<?php printf(__('<a href="feed:%1$s">Entries (RSS)</a> and <a href="feed:%2$s">Comments (RSS)</a>.'), get_bloginfo('rss2_url'), get_bloginfo('comments_rss2_url')); ?>
		<!-- <?php printf(__('%1$s queries.'), get_num_queries()); ?> <?php printf(__('%1$s seconds.'), timer_stop(1)); ?> -->
		Template developed by <a href="http://www.maxbilbow.com/">Max Bilbow</a> for <a href="http://www.uni-kit.com/">Uni-Kit</a>
	</p>
</div>
</div>

<!-- Gorgeous design by Michael Heilemann - http://binarybonsai.com/kubrick/ -->
<?php /* "Just what do you think you're doing Dave?" */ ?>

		<?php wp_footer(); ?>
</body>
</html>
