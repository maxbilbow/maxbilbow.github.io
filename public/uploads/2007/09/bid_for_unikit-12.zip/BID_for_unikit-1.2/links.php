<?php
/*
Template Name: TPL_Links
*/
?>

<?php get_header(); ?>

<?php //get_sidebar(); ?>

<div id="content" class="widecolumn">

<h2><?php _e("Links"); ?>:</h2>
<ul>
<?php get_links_list(); ?>
</ul>

</div>

<?php get_footer(); ?>
