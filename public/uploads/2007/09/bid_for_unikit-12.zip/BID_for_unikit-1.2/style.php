<?php

require_once( dirname(__FILE__) . '../../../../wp-config.php');
header("Content-type: text/css"); 


// GENERAL

	// SITE WIDTH
	if (get_settings( 'rf_sitewidth' ) === FALSE) { $sitewidth = "760"; } else { $sitewidth = get_settings( 'rf_sitewidth' ); }

	// WIDTH TYPE
	if (get_settings( 'rf_sitewidthtype' ) == "") { $sitewidthtype = "px"; } else { $sitewidthtype = get_settings( 'rf_sitewidthtype' ); }

	// SITE FONT
	if (get_settings( 'rf_font' ) == "") { $font = '"Lucida Grande", Verdana, Arial, Sans-Serif'; } else { $font = stripslashes(get_settings( 'rf_font' )); }

	// BACKGROUND COLOR
	if (get_settings( 'rf_bgcolor' ) == "") { $bgcolor = "#000"; } else { $bgcolor = "#".get_settings( 'rf_bgcolor' ); }

	// TOP AND BOTTOM PADDING
	if (get_settings( 'rf_topbottompadding' ) == "") { $topbottompadding = "0"; } else { $topbottompadding = get_settings( 'rf_topbottompadding' ); }

// HEADER

	// HEADER COLOR
	if (get_settings( 'rf_headerbgcolor' ) == "") { $headerbgcolor = "#D82"; } else { $headerbgcolor = "#".get_settings( 'rf_headerbgcolor' ); }

	// SITE TITLE COLOR
	if (get_settings( 'rf_sitetitlecolor' ) == "") { $sitetitlecolor = "#FFF"; } else { $sitetitlecolor = "#".get_settings( 'rf_sitetitlecolor' ); }

	// TAG LINE COLOR
	if (get_settings( 'rf_taglinecolor' ) == "") { $taglinecolor = "#FFF"; } else { $taglinecolor = "#".get_settings( 'rf_taglinecolor' ); }


// NAVIGATION
	
	// NAVIGATION COLOR
	if (get_settings( 'rf_navbgcolor' ) == "") { $navbgcolor = "#000000"; } else { $navbgcolor = "#".get_settings( 'rf_navbgcolor' ); }

	// LINK COLOR
	if (get_settings( 'rf_navlinkcolor' ) == "") { $navlinkcolor = "#FFF"; } else { $navlinkcolor = "#".get_settings( 'rf_navlinkcolor' ); }

	// LINK HOVER COLOR
	if (get_settings( 'rf_navlinkhovercolor' ) == "") { $navlinkhovercolor = "#FFF"; } else { $navlinkhovercolor = "#".get_settings( 'rf_navlinkhovercolor' ); }


// CHILD PAGE NAVIGATION
	
	// CHILD PAGE NAVIGATION COLOR
	if (get_settings( 'rf_childnavbgcolor' ) == "") { $childnavbgcolor = "#333333"; } else { $childnavbgcolor = "#".get_settings( 'rf_childnavbgcolor' ); }

	// LINK COLOR
	if (get_settings( 'rf_childnavlinkcolor' ) == "") { $childnavlinkcolor = "#FFF"; } else { $childnavlinkcolor = "#".get_settings( 'rf_childnavlinkcolor' ); }

	// LINK HOVER COLOR
	if (get_settings( 'rf_childnavlinkhovercolor' ) == "") { $childnavlinkhovercolor = "#FFF"; } else { $childnavlinkhovercolor = "#".get_settings( 'rf_childnavlinkhovercolor' ); }


// MAIN CONTENT
	
	// MAIN CONTENT COLOR
	if (get_settings( 'rf_mainbgcolor' ) == "") { $mainbgcolor = "#EEE"; } else { $mainbgcolor = "#".get_settings( 'rf_mainbgcolor' ); }

	// TEXT COLOR
	if (get_settings( 'rf_maintextcolor' ) == "") { $maintextcolor = "#333"; } else { $maintextcolor = "#".get_settings( 'rf_maintextcolor' ); }

	// TEXT LINK COLOR
	if (get_settings( 'rf_maintextlinkcolor' ) == "") { $maintextlinkcolor = "#28C"; } else { $maintextlinkcolor = "#".get_settings( 'rf_maintextlinkcolor' ); }

	// TEXT LINK HOVER COLOR
	if (get_settings( 'rf_maintextlinkhovercolor' ) == "") { $maintextlinkhovercolor = "#28C"; } else { $maintextlinkhovercolor = "#".get_settings( 'rf_maintextlinkhovercolor' ); }

	// POST TITLE COLOR
	if (get_settings( 'rf_mainposttitlecolor' ) == "") { $mainposttitlecolor = "#333"; } else { $mainposttitlecolor = "#".get_settings( 'rf_mainposttitlecolor' ); }

	// POST TITLE HOVER COLOR
	if (get_settings( 'rf_mainposttitlehovercolor' ) == "") { $mainposttitlehovercolor = "#28C"; } else { $mainposttitlehovercolor = "#".get_settings( 'rf_mainposttitlehovercolor' ); }

	// POST INFO COLOR
	if (get_settings( 'rf_mainpostinfocolor' ) == "") { $mainpostinfocolor = "#AAA"; } else { $mainpostinfocolor = "#".get_settings( 'rf_mainpostinfocolor' ); }

	// POST INFO LINK COLOR
	if (get_settings( 'rf_mainpostinfolinkcolor' ) == "") { $mainpostinfolinkcolor = "#AAA"; } else { $mainpostinfolinkcolor = "#".get_settings( 'rf_mainpostinfolinkcolor' ); }

	// POST INFO LINK HOVER COLOR
	if (get_settings( 'rf_mainpostinfolinkhovercolor' ) == "") { $mainpostinfolinkhovercolor = "#28C"; } else { $mainpostinfolinkhovercolor = "#".get_settings( 'rf_mainpostinfolinkhovercolor' ); }

	// BORDER COLOR
	if (get_settings( 'rf_mainbordercolor' ) == "") { $mainbordercolor = "#999"; } else { $mainbordercolor = "#".get_settings( 'rf_mainbordercolor' ); }

	// H1, H2, H3 COLOR
	if (get_settings( 'rf_mainheadercolor' ) == "") { $mainheadercolor = "#333"; } else { $mainheadercolor = "#".get_settings( 'rf_mainheadercolor' ); }


// COMMENTS

	// COMMENTS COLOR
	if (get_settings( 'rf_commentsbgcolor' ) == "") { $commentsbgcolor = "#EEE"; } else { $commentsbgcolor = "#".get_settings( 'rf_commentsbgcolor' ); }

	// TEXT COLOR
	if (get_settings( 'rf_commentstextcolor' ) == "") { $commentstextcolor = "#333"; } else { $commentstextcolor = "#".get_settings( 'rf_commentstextcolor' ); }

	// LINK COLOR
	if (get_settings( 'rf_commentslinkcolor' ) == "") { $commentslinkcolor = "#28C"; } else { $commentslinkcolor = "#".get_settings( 'rf_commentslinkcolor' ); }

	// LINK HOVER COLOR
	if (get_settings( 'rf_commentslinkhovercolor' ) == "") { $commentslinkhovercolor = "#28C"; } else { $commentslinkhovercolor = "#".get_settings( 'rf_commentslinkhovercolor' ); }

	// INFO TEXT COLOR
	if (get_settings( 'rf_commentsinfotextcolor' ) == "") { $commentsinfotextcolor = "#AAA"; } else { $commentsinfotextcolor = "#".get_settings( 'rf_commentsinfotextcolor' ); }

	// INFO LINK COLOR
	if (get_settings( 'rf_commentsinfolinkcolor' ) == "") { $commentsinfolinkcolor = "#AAA"; } else { $commentsinfolinkcolor = "#".get_settings( 'rf_commentsinfolinkcolor' ); }

	// INFO LINK HOVER COLOR
	if (get_settings( 'rf_commentsinfolinkhovercolor' ) == "") { $commentsinfolinkhovercolor = "#28C"; } else { $commentsinfolinkhovercolor = "#".get_settings( 'rf_commentsinfolinkhovercolor' ); }

	// BORDER COLOR
	if (get_settings( 'rf_commentsbordercolor' ) == "") { $commentsbordercolor = "#999"; } else { $commentsbordercolor = "#".get_settings( 'rf_commentsbordercolor' ); }


// BOTTOMBAR

	// BOTTOMBAR COLOR
	if (get_settings( 'rf_bottombgcolor' ) == "") { $bottombgcolor = "#28C"; } else { $bottombgcolor = "#".get_settings( 'rf_bottombgcolor' ); }

	// TITLE COLOR
	if (get_settings( 'rf_bottomtitlecolor' ) == "") { $bottomtitlecolor = "#FFF"; } else { $bottomtitlecolor = "#".get_settings( 'rf_bottomtitlecolor' ); }

	// TEXT COLOR
	if (get_settings( 'rf_bottomtextcolor' ) == "") { $bottomtextcolor = "#FFF"; } else { $bottomtextcolor = "#".get_settings( 'rf_bottomtextcolor' ); }

	// LINK COLOR
	if (get_settings( 'rf_bottomlinkcolor' ) == "") { $bottomlinkcolor = "#FFF"; } else { $bottomlinkcolor = "#".get_settings( 'rf_bottomlinkcolor' ); }

	// LINK HOVER COLOR
	if (get_settings( 'rf_bottomlinkhovercolor' ) == "") { $bottomlinkhovercolor = "#FFF"; } else { $bottomlinkhovercolor = "#".get_settings( 'rf_bottomlinkhovercolor' ); }

	// BORDER COLOR
	if (get_settings( 'rf_bottombordercolor' ) == "") { $bottombordercolor = "#FFF"; } else { $bottombordercolor = "#".get_settings( 'rf_bottombordercolor' ); }


// FOOTER

	// FOOTER COLOR
	if (get_settings( 'rf_footerbgcolor' ) == "") { $footerbgcolor = "#8C2"; } else { $footerbgcolor = "#".get_settings( 'rf_footerbgcolor' ); }

	// TEXT COLOR
	if (get_settings( 'rf_footertextcolor' ) == "") { $footertextcolor = "#FFF"; } else { $footertextcolor = "#".get_settings( 'rf_footertextcolor' ); }

	// LINK COLOR
	if (get_settings( 'rf_footerlinkcolor' ) == "") { $footerlinkcolor = "#FFF"; } else { $footerlinkcolor = "#".get_settings( 'rf_footerlinkcolor' ); }

	// LINK HOVER COLOR
	if (get_settings( 'rf_footerlinkhovercolor' ) == "") { $footerlinkhovercolor = "#FFF"; } else { $footerlinkhovercolor = "#".get_settings( 'rf_footerlinkhovercolor' ); } ?>





body {
font-family: <?php echo $font; ?>;
background-color: <?php echo $bgcolor; ?>;
}

#page {
	margin: <?php echo $topbottompadding; ?>px auto <?php echo $topbottompadding; ?>px auto;
	background-color:<?php echo $mainbgcolor; ?>;
	width:<?php echo $sitewidth.$sitewidthtype; ?>;
}

#topheader, #header {
	background-color:<?php echo $headerbgcolor; ?>;
}

#topheader { 
	height: 18px; 
	width: <?php echo $sitewidth.$sitewidthtype//HEADER_IMAGE_WIDTH; ?>; 
	}

#header {
	height: <?php echo "182px"; //HEADER_IMAGE_HEIGHT; ?>;
	width: <?php echo $sitewidth.$sitewidthtype//HEADER_IMAGE_WIDTH; ?>;
}

#headerimg {
	height: <?php echo "182px"; //HEADER_IMAGE_HEIGHT; ?>;
	width: <?php echo $sitewidth.$sitewidthtype//HEADER_IMAGE_WIDTH;  ?>;
	}


    #header h1 {
 
    color:<?php echo $sitetitlecolor; ?>;

    }
    
    #header h2 {
 
    color:<?php echo $taglinecolor; ?>;
   
    }


#content {
background-color:<?php echo $mainbgcolor; ?>;
}



   
  
        
            .titrePage a:link, .titrePage a:visited, .posttitle a:link, .posttitle a:visited {
            color:<?php echo $mainposttitlecolor; ?>;
            }
            
            .titrePage a:hover, .posttitle a:hover {
            color:<?php echo $mainposttitlehovercolor; ?>;
            }
        
        .postmetadata { /* postinfo */
        color:<?php echo $mainpostinfocolor; ?>;
        border-top:1px solid <?php echo $mainbordercolor; ?>;
        }
        
            .postmetadata a:link, .postmetadata a:visited {
            color:<?php echo $mainpostinfolinkcolor; ?>;
            }
            
            .postmetadata a:hover {
            color:<?php echo $mainpostinfolinkhovercolor; ?>;
            }
        
        .postcontent {
        color:<?php echo $maintextcolor; ?>;
        }
        
       
        
        .postcontent a:link, .postcontent a:visited {
        color:<?php echo $maintextlinkcolor; ?>;
        }
        
        .postcontent a:hover {
        color:<?php echo $maintextlinkhovercolor; ?>;
        }

       
        
        .postcontent h1 {
        color:<?php echo $mainheadercolor; ?>;
        border-bottom:1px solid <?php echo $mainbordercolor; ?>;
        }
        
        .postcontent h2 {
        color:<?php echo $mainheadercolor; ?>;
        border-bottom:1px solid <?php echo $mainbordercolor; ?>;
        }
        
        .postcontent h3 {
        color:<?php echo $mainheadercolor; ?>;
        border-bottom:1px solid <?php echo $mainbordercolor; ?>;
        }
        
   

#comments {
background-color:<?php echo $commentsbgcolor; ?>;
}
    
        #comments a:link, #comments a:visited {
        color:<?php echo $commentslinkcolor; ?>;
        }
        
        #comments a:hover {
	color:<?php echo $commentslinkhovercolor; ?>;
        }
    
    #comments h3 {
    border-bottom:1px solid <?php echo $commentsbordercolor; ?>;
    }

    .comment {
    color:<?php echo $commentstextcolor; ?>;
    }
    
        #comments .commentinfo {
        color:<?php echo $commentsinfotextcolor; ?>;
        border-bottom:1px solid <?php echo $commentsbordercolor; ?>;
        }
        
            #comments .commentinfo a:link, #comments .commentinfo a:visited {
            color:<?php echo $commentsinfolinkcolor; ?>;
            }
            
	#comments .commentinfo a:hover {
	color:<?php echo $commentsinfolinkhovercolor; ?>;
	}


  
   blockquote {
	margin: 15px 30px 0 10px;
	padding-left: 20px;
	border-left: 3px solid <?php echo $bottombordercolor; ?>;
	background-color:<?php echo $bottombgcolor; ?>;;
	}
            blockquote h1, blockquote h2, blockquote h3, blockquote h4 {
            color:<?php echo $bottomtitlecolor; ?>;
           
            }
            
              
                
        blockquote a:link, blockquote a:visited {
        color:<?php echo $bottomlinkcolor; ?>;
        }

        blockquote  a:hover {
	color:<?php echo $bottomlinkhovercolor; ?>;
        }

#wp-calendar {
	color:<?php echo $childnavlinkcolor; ?>;
}

#wp-calendar caption, #wp-calendar th {
	color:<?php echo $navlinkcolor; ?>;
}





#wp-calendar #today {
	color:<?php echo $navlinkcolor; ?>;
}

#wp-calendar a:link, #wp-calendar a:visited {
	color:<?php echo $navlinkhovercolor; ?>;
}

#wp-calendar a:hover {
	color:<?php echo $childnavlinkhovercolor; ?>;
}


#footer {
background-color:<?php echo $footerbgcolor; ?>;
}

    #footer p {
    text-transform:uppercase;
    color:<?php echo $footertextcolor; ?>;
    }
    
    #footer a:link, #footer a:visited {
    color:<?php echo $footerlinkcolor; ?>;
    }
    
    #footer a:hover {
    color:<?php echo $footerlinkhovercolor; ?>;
    }





