<?php get_header(); ?>

<?php //get_sidebar(); ?>

	<div id="content" class="narrowcolumn">

		<h2 class="center"><?php _e('Error 404 - Not Found'); ?></h2>

	</div>


<?php get_footer(); ?>