<?php

function maxmod($option=FALSE) {

//Change [your site] to the address of this wordpress
$theme_dir = "http://[your site]/wp-content/themes/jillij-maxbilbow";

$maxmod = array(

//MENU STRUCTURE
'menu_style' => 0, //0 uses widgets, 1 lists pages only.

//Navbar colour settings
'navbar_color' => '#FFFFFF',
'navbar_background-color' => '#000000',
'navbar2_background-color' => '#333333',
'navbar3_background-color' => '#666666',
'navbar4_background-color' => '#999999',


//the following options will simply override some basic settings in the Stylesheet
//To reset all of these to defaults, simply leave all the options blank.
//Alternatively, you may delete the options below.
//BACKGOROUNDS (uncomment the 3 addresses below ro get a rounded corner effect
'main_background_image' => "",
'page_background_image' => "",//$theme_dir.'/images/jillijbgwide.jpg',
'topheader_background_image' => "",//$theme_dir.'/images/jillijbgtop.jpg',
'footer_background_image' => "",//$theme_dir.'/images/jillijfooter.jpg',

//COLORS
'main_background-color' => '#000000',
'page_background-color' => 'white' ,
'topheader_bacground-color' => '',
'footer_bacground-color' => '',


);



if (!$option)
echo "MAXMOD SIZE: ".sizeof($maxmod);
else
return $maxmod[$option];


}
?>