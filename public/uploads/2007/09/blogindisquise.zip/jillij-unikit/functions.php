<?php

if ( function_exists('register_sidebars') )
	    register_sidebar(array(
	        'before_widget' => '<li>',
	        'after_widget' => '</li>',
	        'before_title' => '<h2>',
        	'after_title' => '</h2>',
    	));

function widget_jillij_search() {
?>

			<li class="LargeMenu"><h2><?php _e('Search'); ?></h2>
						<ul>
							<li><?php include (TEMPLATEPATH . "/searchform.php"); ?>
							</li>
						</ul>
			</li>

<?php
}

function widget_jillij_calendar() {
?>

			<li class="LargeMenu"><h2><?php _e('Archives'); ?></h2>
				<ul>
					<li>
					<?php get_calendar(); ?>
					</li>
				</ul>
			</li>


<?php
}

function widget_jillij_categories($args) {
		extract($args);
		$options = get_option('widget_categories');
		$c = $options['count'] ? '1' : '0';
		$h = $options['hierarchical'] ? '1' : '0';
		$title = empty($options['title']) ? __('Categories') : $options['title'];
?>
			<li><h2><?php echo $title; ?></h2>
				<ul>
				<?php wp_list_cats('sort_column=name&optioncount=$c&hierarchical=$h'); ?>
				</ul>
			</li>


<?php
}

function widget_jillij_gsearch($args) {

		// $args is an array of strings that help widgets to conform to
		// the active theme: before_widget, before_title, after_widget,
		// and after_title are the array keys. Default tags: li and h2.
		extract($args);

		// Each widget can store its own options. We keep strings here.
		$options = get_option('widget_gsearch');
		$title = $options['title'];
		$buttontext = $options['buttontext'];

		// These lines generate our output. Widgets can be very complex
		// but as you can see here, they can also be very, very simple.
		echo '<li class="LargeMenu">'.$before_title .__('Search'). $after_title.'<ul><li>';
		$url_parts = parse_url(get_bloginfo('home'));
		echo '<form id="searchform" action="http://www.google.com/search" method="get" onsubmit="this.q.value=\'site:'.$url_parts['host'].' \'+this.rawq.value"><input name="rawq" size="20" /><input type="hidden" name="q" value="" /><input value="'.$buttontext.'" name="submit" type="submit" /></form>';
		echo '</li></ul>'.$after_widget;
	}

function widget_text_jillij($args, $number = 1) {
	extract($args);
	$options = get_option('widget_text');
	$title = $options[$number]['title'];
	if ( empty($title) )
		$title = '&nbsp;';
	$text = $options[$number]['text'];
?>
		<li class="LargeMenu">
		<?php $title ? print($before_title . $title . $after_title) : null; ?>
			<ul>
			<li><?php echo $text; ?></li>
			</ul>
		<?php echo $after_widget; ?>
<?php
}

function widget_text_register_jillij() {
	$options = get_option('widget_text');
	$number = $options['number'];
	if ( $number < 1 ) $number = 1;
	if ( $number > 9 ) $number = 9;
	for ($i = 1; $i <= 9; $i++) {
		$name = array('Text %s', null, $i);
		register_sidebar_widget($name, $i <= $number ? 'widget_text_jillij' : /* unregister */ '', $i);
	}
}

function widget_jillij_polyglot($args) {
	extract($args);
	$options = get_option('widget_polyglot');
	$title = $options['title'];
	$listtype = $options['listtype'] ? true : false ;

	echo polyglot_list_langs($listtype);
	}

function widget_jillij_subpagehierarchy($args) {
	// $args is an array of strings that help widgets to conform to
	// the active theme: before_widget, before_title, after_widget,
	// and after_title are the array keys. Default tags: li and h2.
	extract($args);

	// Each widget can store its own options. We keep strings here.
	$options = get_option('widget_subpagehierarchy');
	$title = $options['title'];
	$headpage = $options['headpage'];
	settype($headpage,"integer");
	// These lines generate our output. Widgets can be very complex
	// but as you can see here, they can also be very, very simple.
	echo $before_widget . $before_title . $title . $after_title;
	echo "<ul>";
	wp_list_pages("sort_column=menu_order&child_of=$headpage&title_li=" );
	echo "</ul>";
	echo $after_widget;
	}

if ( function_exists('register_sidebar_widget') ) {
    register_sidebar_widget(__('Search'), 'widget_jillij_search');
    register_sidebar_widget('Calendar', 'widget_jillij_calendar');
	register_sidebar_widget('Categories', 'widget_jillij_categories');
	if ( function_exists('widget_subpagehierarchy') )
		register_sidebar_widget('Sub page hierarchy', 'widget_jillij_subpagehierarchy');

	widget_text_register_jillij();

	if ( function_exists('widget_polyglot') )
		register_sidebar_widget('Polyglot', 'widget_jillij_polyglot');
	if ( function_exists('widget_gsearch') )
		register_sidebar_widget('Google Search', 'widget_jillij_gsearch');
}

define('HEADER_IMAGE', '%s/images/jillijheader.jpg'); // %s is theme dir uri
define('HEADER_IMAGE_WIDTH', 720);
define('HEADER_IMAGE_HEIGHT', 182);
define('HEADER_TEXTCOLOR', 'FFFFFF');

function jillij_admin_header_style() {
?>
<style type="text/css">
#headimg {
	margin: 7px 9px 0;
	height: <?php echo HEADER_IMAGE_HEIGHT; ?>px;
	width: <?php echo HEADER_IMAGE_WIDTH; ?>px;
	background: url(<?php header_image() ?>) no-repeat;
}

#headimg h1 a, #desc, #headimg h1 a:hover, #headimg h1 a:visited {
	color:#<?php header_textcolor() ?>;
}

#headimg h1 {
	padding-top: 45px;
	}

#headimg h1, #headimg h1, #headimg h1 a, #headimg h1 a:hover, #headimg h1 a:visited{
	text-decoration: none;
	font-size: 40px;
	text-align: center;
	font-family: 'Trebuchet MS', 'Lucida Grande', Verdana, Arial, Sans-Serif;
	font-weight: bold;
	}

#desc {
	font-size: 1.2em;
	text-align: center;
	}

</style>
<?php
}
function jillij_header_style() {
?>
<style type="text/css">
#headerimg {
	background: url(<?php header_image() ?>) no-repeat;
}

#headerimg h1,#headerimg h1 a, .description, #headerimg h1 a:hover, #headerimg h1 a:visited {
	color:#<?php header_textcolor() ?>;
}

<?php if ( 'blank' == get_header_textcolor() ) { ?>

#headerimg h1, .description {
	display: none;
}

<?php } ?>

</style>
<?php
}
if ( function_exists('add_custom_image_header') ) {
	add_custom_image_header('jillij_header_style', 'jillij_admin_header_style');
}
?>