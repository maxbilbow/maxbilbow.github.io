<?php 
include "constants.php"; 
include "navbar.php";
?>

<?php function maxmod_style($option1 = -1, $option2 = "main",$attribute=""){ 

switch ($option1){
	case -1:
	default:
	?>
	body {
		<?php maxmod_style('attribute','main','background-color'); ?>
		<?php maxmod_style('background_image','main'); ?>
		}

	#topheader {
		<?php maxmod_style('attribute','topheader','background-color'); ?>
		<?php maxmod_style('background_image','topheader'); ?>		
}

	#page {
		<?php maxmod_style('attribute','page','background-color'); ?>
		<?php maxmod_style('background_image','page'); ?>
	}

	#footer {
		<?php maxmod_style('attribute','footer','background-color'); ?>
		<?php maxmod_style('background_image','footer'); ?>

}
<?php  include "navbar.css.php";
	//Other options
	case "background_color":
		if (strlen(maxmod($option2."_".$option1))>0)
			echo 'background-color: '.maxmod($option2.'_'.$option1).';'."\n";
	break;
	case "background_image":
		if (strlen(maxmod($option2."_".$option1))>0)
			echo 'background: url("'.maxmod($option2.'_'.$option1).'");'."\n";
	break;
	case "attribute":
		if (strlen(maxmod($option2."_".$attribute))>0)
			echo "$attribute: ".maxmod($option2.'_'.$attribute).";\n";
	break;
	}
} ?>


