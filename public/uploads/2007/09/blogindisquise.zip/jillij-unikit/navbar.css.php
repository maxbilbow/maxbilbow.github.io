/* Rolling Menu Styles*/

#navbar {
	display: block;
	border: 0px;
	padding: 0px 0px 0px 0px;
	margin: 0px 0px 0px 20px;
	z-index: 5;
	position: relative;
}

#navbar ul {
	width:720px;
	min-height: 30px;
	list-style-type: none;
	padding: 0px 0px 0px 0px;
	margin: 0px 0px 0px 0px;
	z-index: 500;
}

#navbar li {
	display: inline;
	float: left;
	min-height: 20px;
	position: relative;
	text-align: left;
	padding: 5px 16px 5px;
	margin: 0px 0px 0px 0px;
}

#navbar h2 {
	font-size: 1.2em;
	padding: 0;
	margin: 0;
	weight: bold;
}



#navbar li ul {
	width: 150px;
	height: auto;
	top: 100%;
	left: 0px;
}

#navbar li.LargeMenu ul {
	width: 200px;
	height: auto;
	top: 100%;
	left: 0px;
}

#navbar li ul li {
	text-align: left;
	width: 118px;	
	height: auto;
	min-height: auto;
	display: block;
}

#navbar li.LargeMenu ul li {
	text-align: left;
	width: 198px;	
	height: auto;
	min-height: auto;
	display: block;
}

#navbar a {
	text-decoration: none;
	}

#navbar li li ul {
	top: 0;
	left: 0;
}

#navbar li li:hover ul {
	left: 150px;
}

/* initialy hide all sub sidemenus */
#navbar ul ul,
#navbar ul li:hover ul ul,
#navbar ul ul li:hover ul ul,
#navbar ul ul ul li:hover ul ul,
#navbar ul ul ul ul li:hover ul ul {
	position: absolute;
	display:none;
}

/* display them on hover */
#navbar li:hover ul,
#navbar ul li:hover ul,
#navbar ul ul li:hover ul,
#navbar ul ul ul li:hover ul,
#navbar ul ul ul ul li:hover ul,
#navbar ul ul ul ul ul li:hover ul {
 	 display: block;
}

#navbar #PhpWebcontent {
	display:none;
}	

/* define the consecutive colors */

#navbar {
	color: <?php echo maxmod('navbar_color');?>;
}

#navbar ul{
	background-color: <?php echo maxmod('navbar_background-color');?>;
	-moz-opacity:0.88; /* for mozilla */
	opacity: 0.88; /* for safari */
	khtml-opacity: 0.88 /* for konquerer and older safari */
}

#navbar ul ul {
	background-color: <?php echo maxmod('navbar_background-color');?>;
}
#navbar ul li {
	background-color: <?php echo maxmod('navbar_background-color');?>;
}

#feeds li {
  background-color: url(images/feed.png) top left no-repeat;
  padding-left: 18px;
}

#navbar h2 {
	color: <?php echo maxmod('navbar_color');?>;
}

#navbar a {
	color: <?php echo maxmod('navbar_color');?>;
	}

#navbar ul li:hover {
	background-color: <?php echo maxmod('navbar2_background-color');?>;
}

#navbar ul li ul {

}

#navbar ul li ul li {
	background-color: <?php echo maxmod('navbar2_background-color');?>;
}

#navbar ul li ul li:hover {
	background-color: <?php echo maxmod('navbar3_background-color');?>;
}

#navbar ul li ul ul li{
	background-color: <?php echo maxmod('navbar3_background-color');?>;
	
}

#navbar ul li ul ul li:hover {
	background-color: <?php echo maxmod('navbar4_background-color');?>;
}
