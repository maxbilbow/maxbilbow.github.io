<?php 
function navbar(){
	switch (maxmod('menu_style')) {
	case 0:
		do_sidebar();
		break;
	case 1: ?>
<div id="navbar">
		<ul>
<h2><?php wp_list_pages('title_li=' ); ?><?php //include (TEMPLATEPATH . "/searchform.php"); ?>
</ul>
</div>
<?php
		break;

	}
}

function do_sidebar() {?>

<div id="<?php echo maxmod('menu_style')==0?"navbar":"sidebar";?>">

		<ul>
				<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>

			<?php wp_list_pages('title_li=<h2>'.__('Pages').'</h2>' ); ?>

			<li class="LargeMenu"><h2><?php _e('Archives'); ?></h2>
				<ul>
					<li>
					<?php get_calendar(); ?>
					</li>
				</ul>
			</li>

			<?php wp_list_categories('title_li=<h2>'.__('Categories').'</h2>&show_count=1&orderby=name&hierarchical=1' ); ?>

			<?php
			if (get_bloginfo('version')<'2.1')
				{
				get_links_list();
				}
			else
				{
				wp_list_bookmarks('title_li=<h2>'.__('Bookmarks').'</h2>');
				}
			?>

			<?php if (function_exists('xdforum_get_last_threads'))
				{
				echo xdforum_get_last_threads();
				}
			?>

			<li><h2><?php _e('Meta'); ?></h2>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a></li>
					<li><a href="http://gmpg.org/xfn/"><?php _e('<abbr title="XHTML Friends Network">XFN</abbr>'); ?></a></li>
					<?php wp_meta(); ?>
				</ul>
			</li>



			<li class="LargeMenu"><h2><?php _e('Search'); ?></h2>
				<ul>
					<li><?php include (TEMPLATEPATH . "/searchform.php"); ?>
					</li>
				</ul>
			</li>

			<?php if (function_exists('gengo_list_languages'))
				{
				echo '<li><h2>'.__('Languages', GENGO_DOMAIN).'</h2><ul>';
				echo gengo_list_languages();
				echo '</ul></li>';
				}
			?>

			<?php endif; ?>
		</ul>

</div>

<?php } ?>
