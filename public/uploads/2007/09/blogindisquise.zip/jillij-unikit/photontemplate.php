<?php photon_process(); ?><?php get_header(); ?>

<?php get_sidebar(); ?>

	<div id="content" class="narrowcolumn">

	<?php /* If this is the frontpage */ if ( is_home() & (!isset($_GET['a']) | $_GET['a']!='phpwebgallery')) { ?>
		<?php if (is_home() & (!isset($_GET['a']) | $_GET['a']!='phpwebgallery') & function_exists('Photon_random_image_bare')) { ?>
					<div class="titrePage"><a href="<?php echo PHOTON_GALTITLE; ?>"><?php echo PHOTON_GALTITLE; ?></a></div>
					<hr/>
					<h2><?php echo __("Random pictures","photon") ?></h2>
					<?php echo Photon_random_image_bare(PHOTON_NUMBERPICT); ?>
					<div class="titrePage"><a href="<?php echo get_settings('home'); ?>">Blog</a></div>
					<hr/>
		<?php } ?>
	<?php } ?>

	<?php photon_display_phpwebgallery() ?>

	</div>

<?php get_footer(); ?>
